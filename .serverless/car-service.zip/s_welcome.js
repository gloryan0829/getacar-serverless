
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'day34',
  applicationName: 'getacar',
  appUid: 'QZv9mwRyzwWfxBtQdY',
  orgUid: 'JNd9dgRTmCk3W2y5x7',
  deploymentUid: 'a133d641-b65c-4b7e-a056-495e7a18f0ab',
  serviceName: 'car-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.12',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'welcome', timeout: 6 };

try {
  const userHandler = require('./src/routes/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.welcome, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}